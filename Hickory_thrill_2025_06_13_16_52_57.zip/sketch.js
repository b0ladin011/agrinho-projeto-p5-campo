function setup() {
  createCanvas(600, 400);
}

function draw() {
  // Céu
  background(135, 206, 235); // cor azul clara do céu
  
  // Grama
  fill(34, 139, 34); // cor verde para a grama
  noStroke();
  rect(0, height * 0.7, width, height * 0.3); // criando a base da grama
  
  // Sol
  noStroke();
  fill(255, 223, 0); // cor amarela do sol
  ellipse(500, 100, 100, 100); // desenha o sol
  
  // Árvores
  drawTree(150, 250);  // árvore 1
  drawTree(400, 270);  // árvore 2
  
  // Detalhes
  drawCloud(100, 80); // nuvem 1
  drawCloud(300, 120); // nuvem 2
}

// Função para desenhar uma árvore
function drawTree(x, y) {
  // Trunk
  fill(139, 69, 19); // cor marrom para o tronco
  rect(x - 10, y, 20, 40); // tronco da árvore
  
  // Foliage
  fill(0, 128, 0); // cor verde para a folhagem
  ellipse(x, y - 20, 60, 60); // folhagem da árvore
}

// Função para desenhar uma nuvem
function drawCloud(x, y) {
  fill(255); // cor branca para a nuvem
  ellipse(x, y, 60, 40);
  ellipse(x + 30, y, 60, 40);
  ellipse(x + 60, y, 60, 40);
}
